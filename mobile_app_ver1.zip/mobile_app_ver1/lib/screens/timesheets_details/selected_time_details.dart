class SelectedTimeDetails {
  String startDateStr = "";
  String startTimeStr = "";
  String endDateStr = "";
  String endTimeStr = "";
  String breakTime = "";

  DateTime startDateTime;
  DateTime endDateTime;
  DateTime startBreakTime;
  DateTime endBreakTime;
}
