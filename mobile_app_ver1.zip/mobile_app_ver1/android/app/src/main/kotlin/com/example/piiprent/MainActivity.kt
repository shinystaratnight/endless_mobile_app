package com.example.piiprent

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
